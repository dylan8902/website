<?php
function query($sql) {
	$mysql_host = "mysql14.000webhost.com";
	$mysql_database = "a2179352_db";
	$mysql_user = "a2179352_db";
	$mysql_password = "a2179352_";
	
	$dbconn = mysql_connect($mysql_host, $mysql_user, $mysql_password) or die ('Error:  ' . mysql_error());
	mysql_select_db($mysql_database, $dbconn);
	$result=mysql_query($sql, $dbconn);
	mysql_close($dbconn);

	return $result;
}

function timeToString ($time) {

	$format = "F m, Y g:i a";
	$timeyear = 365 * 24 * 60 * 60;
	$timemonth = 30 * 7 * 24 * 60 * 60;
	$timeweek = 7 * 24 * 60 * 60;
	$timeday = 24 * 60 * 60;
	$timehour = 60 * 60;
	$timemins = 60;
	$timeseconds = 1;
	$today = time();
	$x = $today - $time;

	if($x >= $timeyear){$x = date($format, $x); $dformat=""; $pre ="On the date: "; 
	}elseif($x >= $timemonth){$x = date($format, $x); $dformat=""; $pre ="On the date: ";
	}elseif($x >= $timeday){$x = round($x / $timeday); $dformat="days ago"; $pre =" "; $x = round($x);
	}elseif($x >= $timehour){$x = round($x / $timehour); $dformat="hours ago"; $pre =" "; 
	}elseif($x >= $timemins){$x = round($x / $timemins); $dformat="minutes ago"; $pre =" ";
	}elseif($x >= $timeseconds){$x = round($x / $timeseconds); $dformat="seconds ago"; $pre =" "; 
	}
	return $pre." ".$x." ".$dformat;
}

function eatCookie() {
	$res = query("SELECT uid FROM sessions WHERE hash = '".$_COOKIE['session']."' ORDER BY sessionid DESC LIMIT 1;");
	if(mysql_numrows($res)<1) {
		print "Session Error.";
		exit();
	}
	$user['uid'] = mysql_result($res,0,'uid');
	
	$res = query("SELECT * FROM users WHERE uid ='{$user['uid']}' LIMIT 1;");
	$user['username'] = mysql_result($res,0,'username');
	$user['mac'] = mysql_result($res,0,'mac');
	
	$res = query("SELECT * FROM likes where uid = '{$user['uid']}' AND source = 'facebook';");
	for($a=0;$a<mysql_numrows($res);$a++) {
		$user['likes']['facebook'][$a] = mysql_result($res,$a,'artist');
	}
	$res = 
	query("SELECT * FROM likes where uid = '{$user['uid']}' AND source = 'lastfm';");
	for($a=0;$a<mysql_numrows($res);$a++) {
		$user['likes']['lastfm'][$a] = mysql_result($res,$a,'artist');
	}
	
	return $user;
}
?>