<?php
include_once('../functions.php');
$user = eatCookie();

$api = "ea5099237517b2b08252aed02e06a3ea";
$secret = "6d597d4c6c0b1b1a8a4579964abb6758";
?>
<!DOCTYPE html> 
<html lang='en-gb'> 
<head> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
 	<title>CLEVER SOUNDS</title> 
	<meta name="description" content="Playing your kind of music, wherever you are." /> 
	<meta name="keywords" content="Bluetooth, Music, Jukebox" /> 
  	<meta name="author" content="Dylan Jones" /> 
	<link rel="icon" href="/favicon.ico" type="image/x-icon" /> 
	<?php include('../style.php'); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#settings').toggle(function() {
				$('#setting-choices').fadeIn(500);
			},function() {
				$('#setting-choices').fadeOut(500);
			});
			
			$('#submit').click(function() {
				var user = $('#username').val();
				$.ajax({
				  type		: 'GET',
				  dataType	: 'jsonp',
				  url		: 'http://ws.audioscrobbler.com/2.0/',
				  data		: 'method=user.gettopartists&format=json&user='+user+'&api_key=ea5099237517b2b08252aed02e06a3ea',
				  success	: 
					function(reply){
						var a =0;
						var upload = [];
						var image = [];
						$('#artists').html('');
						for(var i in reply.topartists.artist) {
							upload[a] = reply.topartists.artist[i].name;
							image[a] = 'http://www.bbc.co.uk/music/images/artists/542x305/'+reply.topartists.artist[i].mbid+'.jpg';							a++;
						}
						a=0;
						for(var a in upload) {
							$.ajax({
							  type     : 'GET',
							  dataType : 'jsonp',
							  url      : 'http://api.cleversounds.info/like.php',
							  data     : 'source=lastfm&uid=<?php print $user['uid']; ?>&image='+image[a]+'&artist='+upload[a],
							  success  : 
								function(reply){
								   $('#artists').append('<li>'+reply.data+'</li>');
								}
							});
						}
					},
					
				  error		:
					function(){
					$('#artists').html('Sorry, LastFM does not want to talk right now');
					}
				});
				
				return true;;
			});
	});
	</script>
</head> 
<body>
	<h1>CLEVER SOUNDS</h1>
	<p class='nav'><a href='/' class='tab'>HOME</a> <a href='/' id='settings' class='tab'>SETTINGS</a> <a href='/account/?logout=1'' class='tab'>LOGOUT</a></p>
	<p id='setting-choices' class='box'><a href='link.php'>LINK ACCOUNTS</a> | <a href='mac.php?reset=<?php print $user['uid']; ?>'>CHANGE PHONE</a> | <a href='password.php'>CHANGE PASSWORD</a> | <a href='delete.php'>DELETE ACCOUNT</a></p>
	<h2 id='line'><label for='username'>What is your LastFM username? </label><br><input type='text' id='username' placeholder='username' /> <input id='submit' type='submit' value='Find Artists' /></h2>
	<p id='artists'></p>
	<h2><a href='/account/link.php'>choose more accounts</a> <a href='/'>or go back</a></h2>
</body>
</html>