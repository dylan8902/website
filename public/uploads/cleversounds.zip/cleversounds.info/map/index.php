<?php
include_once('../functions.php');
$user = eatCookie();
?>
<!DOCTYPE html> 
<html lang='en-gb'> 
<head> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
 	<title>CLEVER SOUNDS</title> 
	<meta name="description" content="Playing your kind of music, wherever you are." /> 
	<meta name="keywords" content="Bluetooth, Music, Jukebox" /> 
  	<meta name="author" content="Dylan Jones" /> 
	<link rel="icon" href="/favicon.ico" type="image/x-icon" /> 
	<?php include('../style.php'); ?>
	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script> 
	<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script> 
	
		<script type="text/javascript"> 
		var map;
		var latlng = new google.maps.LatLng(53.2128983,-1.96384);
		
		function movetoPosition(thislatlng) {
			window.location = "http://things.dylanjones.info/localtags/geo/"+thislatlng;
		}
				
		function createMap() {
			var myOptions = {
			  zoom: 6,
			  center: latlng,
			  disableDefaultUI: true,
			  scaleControl: true,
			  mapTypeId: google.maps.MapTypeId.ROADMAP
			};
			map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
 
			<?php
			//if there is a user, show their plays
			if(isset($user)) {
				$res = query("SELECT DISTINCT(location) FROM plays WHERE uid= '{$user['uid']}' LIMIT 500;");
				for($a=0;$a<mysql_numrows($res);$a++) {
					$location = mysql_result($res,$a,'location');
					$query = query("SELECT lat, lng FROM locations WHERE location ='$location';");
					$coords = mysql_result($query,0,'lat').",".mysql_result($query,0,'lng');
					print "
				
						var Latlng$a = new google.maps.LatLng($coords);
						var marker$a = new google.maps.Marker({
							position: Latlng$a,
							map: map,
							clickable: true
						});
					
						";
				}
			}
			?>
			
			}
	</script> 
 
</head> 
<body onload='createMap()'> 

	<h1>CLEVER SOUNDS</h1>
	<p class='nav'><a href='/' class='tab'>HOME</a> <a href='/' id='settings' class='tab'>SETTINGS</a> <a href='/account/?logout=1'' class='tab'>LOGOUT</a></p>
	<p id='setting-choices' class='box'><a href='link.php'>LINK ACCOUNTS</a> | <a href='mac.php?reset=<?php print $user['uid']; ?>'>CHANGE PHONE</a> | <a href='password.php'>CHANGE PASSWORD</a> | <a href='delete.php'>DELETE ACCOUNT</a></p>
	
	<?php
	if(isset($user))
		print "<p>This map shows the locations where a track has been played for you</p>\n";
	?>
	
	<div id="map_canvas" style="width:99%; height:400px; margin:5px;"></div> 
  
</body> 
</html>