<style>
	/*  RESET */
	html, body, div, span, applet, object, iframe,
	h1, h2, h3, h4, h5, h6, p, blockquote, pre,
	a, abbr, acronym, address, big, cite, code,
	del, dfn, em, font, img, ins, kbd, q, s, samp,
	small, strike, strong, sub, sup, tt, var,
	b, u, i, center,
	dl, dt, dd, ol, ul, li,
	fieldset, form, label, legend,
	table, caption, tbody, tfoot, thead, tr, th, td { color:inherit; text-decoration:none; margin: 0; padding: 0; border: 0; outline: 0; font-size: 100%; vertical-align: baseline; background: transparent; }
	body { line-height: 1; }
	:focus { outline: 0; }
	/* END RESET, START STYLING */
	html { font-family:helvetica,sans-serif; font-size:12pt; background:black; margin:50px; min-width:860px; }
	h1 { width:500px; padding:10px; background:white; font-size:350%; margin:10px; margin-left:5px; margin-bottom:0px; }
	h2 { padding:13px; background:white; font-size:170%; margin:5px;}
	.nav { font-size:90%; display:inline-block; margin-top:0px; margin-bottom:0px; }
	#setting-choices { background:black; font-size:90%; margin-top:0px; margin-bottom:0px; }
	#setting-choices a { color:#909090;; background:#101010; padding:3px; }
	#setting-choices a:hover { color:white; }
	.tab { margin:5px; cursor:pointer; background:black; color:white; padding:3px; border:2px solid black; }
	.tab:hover { color:red; }
	.box { display:none; }
	p { font-size:120%; padding:10px; background:white; margin:5px; margin-top,margin-bottom:1px; }
	a:hover { color:red; }
	form { padding:10px; background:white; margin:5px; }
	input { border:1px dotted black; }
	input:focus { border-color:red; }
	.submit { cursor: pointer }
	img { vertical-align:middle; }
</style>