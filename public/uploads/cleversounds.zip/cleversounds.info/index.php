<?php
if(isset($_COOKIE['session'])) {
	header('Location: /account');
	exit();
}
?>
<!DOCTYPE html> 
<html lang='en-gb'> 
<head> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
 	<title>CLEVER SOUNDS</title> 
	<meta name="description" content="Playing your kind of music, wherever you are." /> 
	<meta name="keywords" content="Bluetooth, Music, Jukebox" /> 
  	<meta name="author" content="Dylan Jones" /> 
	<link rel="icon" href="/favicon.ico" type="image/x-icon" /> 
	<?php include('style.php'); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script>
		$(document).ready(function() {
			$('.tab').click(function() {
				$('.tab').css("background-color","black");
				$('.tab').css("color","white");
				$(this).css("background-color","white");
				$(this).css("color","black");
				var id = $(this).attr('id');
				$('.box').hide();
				$('#'+id+'-form').slideDown(600);			
			});
		});
	</script>
</head> 
<body>
	<h1>CLEVER SOUNDS</h1>
	<p>TAKE YOUR KIND OF MUSIC, WHEREVER YOU GO<br><br>
	REGISTER YOUR PHONE WITH US, TELL US WHAT MUSIC YOU LIKE AND WE WILL PLAY YOUR FAVOURITE SONGS IN THE PLACES YOU VISIT
	</p>
	<p style='background-color:black;padding:0px;float:left;width:510px;margin-bottom:10px;'><img src='/images/what.png' height='200' /></p>
	<div style='float:right;width:340px;'>
	<p><span id='register' class='tab' style='background:white;color:black;'>REGISTER</span> <span id='login' class='tab'>LOGIN</span></p> 
	<form id='register-form' method='post' action='register.php' class='box' style='display:block;'>
		<table>
			<tr><td><label for='username'>Username </label> </td><td><input type='text' id='username' name='username' /></td></tr>
			<tr><td><label for='password'>Password </label> </td><td><input type='password' id='password' name='password' /></td></tr>
			<tr><td><label for='password-again'>Confirm </label> </td><td><input type='password' id='password-again' name='password-again' /></td></tr>
			<tr><td><input class='submit' type='submit' value='REGISTER' /></td></tr>
		</table>
	</form>
	<form id='login-form' method='post' action='login.php' class='box'>
		<table>
			<tr><td><label for='username'>Username </label> </td><td><input type='text' id='username' name='username' value='<?php print $_COOKIE['remember-user']; ?>' /></td></tr>
			<tr><td><label for='password'>Password </label> </td><td><input type='password' id='password' name='password' value='<?php if(isset($_COOKIE['remember-user'])) { print base64_decode($_COOKIE['remember-pass']); } ?>'/></td></tr>
			<tr><td><label for='remember'>Remember Me </label> </td><td><input type='checkbox' id='remember' name='remember' <?php if(isset($_COOKIE['remember-user'])) { print "checked"; } ?> /></td></tr>
			<tr><td><input class='submit' type='submit' value='LOGIN' /></td></tr>
		</table>
	</form>
	</div>
	
	<div id='about' style='clear:both;'>
	<p>HOW? You mobile phone's bluetooth MAC address is registered online and you add your favourite artists via Facebook, Twitter, MySpace and LastFM.
	When your bluetooth is picked up by a participating venue, we tell them what music you like and they play it!</p>
	</div>
</body>
</html>