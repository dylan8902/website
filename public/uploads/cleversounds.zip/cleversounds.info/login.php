<?php
include_once('functions.php');
//are all details sent
if((isset($_POST['username']))&&(isset($_POST['password']))) {

	//lowercasify
	$_POST['username'] = strtolower($_POST['username']);
	
	//check username and password
	$res = query("SELECT uid FROM users WHERE username = '{$_POST['username']}' AND password = '".md5($_POST['password'])."';");
	if(mysql_numrows($res) > 0) {
		$uid = mysql_result($res,0,'uid');
		//save session cookie
		query("INSERT INTO sessions VALUES ('', '".md5(date().$_POST['username'])."', '$uid', '".$HTTP_SERVER_VARS['REMOTE_ADDR']."');");
		header('Location: /account/');
		setcookie("session",md5(date().$_POST['username']),0,'/','cleversounds.info');
		if($_POST['remember']=='on') {
			setcookie("remember-user",$_POST['username'],time()+31536000,'/','cleversounds.info');
			setcookie("remember-pass",base64_encode($_POST['password']),time()+31536000,'/','cleversounds.info');
		}
		else {
			if(isset($_COOKIE['remember-user'])) {
				setcookie("remember-user",'',2,'/','cleversounds.info');
				setcookie("remember-pass",'',2,'/','cleversounds.info');
			}		
		}
	}
	else {
		print "Username and password incorrect.";
	}
}
else
	print "You missed something.";
?>