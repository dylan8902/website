<?php
include_once('../functions.php');
$user = eatCookie();
if(isset($_GET['code'])==false) {
	$loc = "https://graph.facebook.com/oauth/authorize?client_id=140312116007584&redirect_uri=http://cleversounds.info/facebook/&scope=";
	$loc .= "user_activities,friends_activities,user_interests,friends_interests,user_likes,friends_likes";
	header("Location: $loc");
}
else {
$url = "http://graph.facebook.com/oauth/access_token?client_id=140312116007584&redirect_uri=http://cleversounds.info/facebook/&client_secret=d450b954a4cae0f50ce8d5d532c078e9&code={$_GET['code']}";
$auth_token = file_get_contents($url);
$auth_token = str_replace('&amp;','&',$auth_token);
?>
<!DOCTYPE html> 
<html lang='en-gb'> 
<head> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
 	<title>CLEVER SOUNDS</title> 
	<meta name="description" content="Playing your kind of music, wherever you are." /> 
	<meta name="keywords" content="Bluetooth, Music, Jukebox" /> 
  	<meta name="author" content="Dylan Jones" /> 
	<link rel="icon" href="/favicon.ico" type="image/x-icon" /> 
	<?php include('../style.php'); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script>
		$(document).ready(function() {
			$('#settings').toggle(function() {
				$('#setting-choices').fadeIn(500);
			},function() {
				$('#setting-choices').fadeOut(500);
			});
			
			$.ajax({
			  type     : 'GET',
			  dataType : 'jsonp',
			  url      : 'https://graph.facebook.com/me/',
			  data     : 'fields=music&<?php print $auth_token; ?>',
			  success  : 
				function(reply){
				   var a =0;
				   var upload = [];
				   var image = [];
				   if(reply.music.data[0].name.length > 1) {
					for(var i in reply.music.data) {
						var artist = reply.music.data[i];
						if(typeof artist.name != "undefined") {
						  upload[a] = artist.name;
						  image[a] = 'http://graph.facebook.com/'+artist.id+'/picture';
						  $('#artists').append('<img src="http://graph.facebook.com/'+artist.id+'/picture" title="'+artist.name+'" /> ');
						  a++;
						}
					 }
				  }
				  else {
					$('#artists').html('Sorry, Facebook does not want to talk right now');
				  }
				  a=0;
				  for(var a in upload) {
					$.ajax({
					  type     : 'GET',
					  dataType : 'jsonp',
					  url      : 'http://localhost/api/like.php',
					  data     : 'source=facebook&uid=<?php print $user['uid']; ?>&image='+image[a]+'&artist='+upload[a],
					  success  : 
						function(reply){
						   $('#artists').append('<li>'+reply.data+'</li>');
						}
					});
				  }
				}
			});
		});
	</script>
</head> 
<body>
	<h1>CLEVER SOUNDS</h1>
	<p class='nav'><a href='/' class='tab'>HOME</a> <a href='/' id='settings' class='tab'>SETTINGS</a> <a href='/account/?logout=1'' class='tab'>LOGOUT</a></p>
	<p id='setting-choices' class='box'><a href='link.php'>LINK ACCOUNTS</a> | <a href='mac.php?reset=<?php print $user['uid']; ?>'>CHANGE PHONE</a> | <a href='password.php'>CHANGE PASSWORD</a> | <a href='delete.php'>DELETE ACCOUNT</a></p>
	<h2>Your Facebook profile says you like:</h2>
	<p id='artists'></p>
	<h2><a href='/account/link.php'>choose more accounts</a> <a href='/'>or go home</a></h2>
</body>
</html>
<?php
}
?>