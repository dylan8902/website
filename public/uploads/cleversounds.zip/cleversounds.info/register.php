<?php
include_once('functions.php');
//are all details sent
if((isset($_POST['username']))&&(isset($_POST['password']))&&(isset($_POST['password-again']))) {

	//lowercasedehtmlisify
	$_POST['username'] = strtolower(strip_tags($_POST['username']));
	
	//check username is unique
	if(mysql_numrows(query("SELECT uid FROM users WHERE username = '{$_POST['username']}';")) > 0) {
		print "Username already exists.";
		exit();
	}

	//are the passwords the same
	if($_POST['password'] != $_POST['password-again']) {
		print "Passwords do not match.";
		exit();
	}

	//success
		query("INSERT into users VALUES ('', '{$_POST['username']}', '".md5($_POST['password'])."', '0');");
		$uid = mysql_result(query("SELECT uid FROM users WHERE username = '{$_POST['username']}' LIMIT 1;"),0,'uid');
		query("INSERT INTO sessions VALUES ('', '".md5(date().$_POST['username'])."', '$uid', '".$HTTP_SERVER_VARS['REMOTE_ADDR']."');");
		header('Location: /account/');
		setcookie("session",md5(date().$_POST['username']),0,'/','cleversounds.info');
}
else
	print "Something is missing";
?>