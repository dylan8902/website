<?php
include_once('../functions.php');
if(isset($_GET['demo'])) {
	$res=query("SELECT mac FROM users ORDER BY RAND() LIMIT 20;");
	print $_GET['callback']."({\"data\":[";
	for($a=1;$a<mysql_numrows($res);$a++) {
		print "{\"mac\":\"".mysql_result($res,$a,'mac')."\"},";
	}
	print "{\"mac\":\"123456789013\"}]})";
}
else {
	exec('C:/bluetooth.bat');
	header('Content-type: text/javascript');
	$a=0;
	$file = mb_convert_encoding(file_get_contents("c:\\devices.txt"),'UTF-8','UNICODE');
	$devices = explode('Address           : ',$file);
	foreach($devices as $device) {
		$line = explode('
	',$device);
	$result[$a] = str_replace(':','',$line[0]);
	$a++;
	}
	print $_GET['callback']."({\"data\":[";
	for($a=1;$a<count($result);$a++) {
		print "{\"mac\":\"".$resullt[$a]."\"},";
	}
	print "{\"mac\":\"123456789013\"}]})";
}

?>