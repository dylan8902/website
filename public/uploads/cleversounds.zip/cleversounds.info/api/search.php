<?php
header('Content-type: text/javascript');
print $_GET['callback']."(".file_get_contents("http://developer.echonest.com/api/v4/artist/search?api_key=XACSR313AVJ9RJHE1&format=json&name=".urlencode($_GET['artist'])).")";
?>