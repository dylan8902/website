<?php
header('Content-type: text/javascript');
include_once('../functions.php');
if((isset($_GET['song']))&&(isset($_GET['location']))&&(isset($_GET['mac']))) {
	$res = query("SELECT uid FROM users WHERE mac = '{$_GET['mac']}' LIMIT 1;");
	if(mysql_numrows($res)>0) {	
		$uid = mysql_result($res,0,'uid');
		$query = "INSERT INTO plays VALUES ('','$uid','".urldecode($_GET['song'])."','".urldecode($_GET['location'])."','".time()."');";
		query($query);
		print $_GET['callback']."({ \"status\":\"OK\"})";
	}
	else {
		print $_GET['callback']."({ \"status\":\"FAIL\"})";
	}
}
else
	print $_GET['callback']."({ \"status\":\"FAIL\"})";
?>