<?php
header('Content-type: text/javascript');
include_once('../functions.php');
if((isset($_GET['source']))&&(isset($_GET['artist']))) {
	$check = mysql_numrows(query("SELECT likeid FROM likes WHERE artist ='".urldecode($_GET['artist'])."' AND uid = '{$_GET['uid']}'"));
	if($check < 1) {
		$query = "INSERT INTO likes VALUES ('','{$_GET['uid']}','".urldecode($_GET['source'])."','".urldecode($_GET['artist'])."','".$_GET['image']."');";
		$res = query($query);
		if($res)
			print $_GET['callback']."({ \"data\": \"<span style='color:red'>Added ".urldecode($_GET['artist'])."</span>\" })";
		else
			print $_GET['callback']."({ \"data\": \"Could not add: ".urldecode($_GET['artist'])."\" })";
	}
	else
		print $_GET['callback']."({ \"data\": \"".urldecode($_GET['artist'])."\" })";
}
else
	print $_GET['callback']."({ \"data\": \"Something went wrong\" })";
?>