<?php
header('Content-type: text/javascript');
print $_GET['callback']."(".file_get_contents("http://ws.audioscrobbler.com/2.0/?method=artist.getinfo&artist=".urlencode($_GET['artist'])."&format=json&api_key=ea5099237517b2b08252aed02e06a3ea").")";
?>