<?php
header('Content-type: text/javascript');
print $_GET['callback']."(".file_get_contents("http://developer.echonest.com/api/v4/artist/similar?api_key=XACSR313AVJ9RJHE1&format=json&results=5&bucket=images&start=0&name=".urlencode($_GET['artist'])).")";
?>