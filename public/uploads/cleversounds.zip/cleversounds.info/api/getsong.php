<?php
header('Content-type: text/javascript');
include_once('../functions.php');

//function to get a random song
function getRandom() {
	$res=query("SELECT title, artist, trackid, recordid FROM rec_track WHERE digitised ORDER BY RAND() LIMIT 1");
	$title= mysql_result($res,0,'title');
	$artist = mysql_result($res,0,'artist');
	$id = mysql_result($res,0,'trackid');
	$url = "http://ury.york.ac.uk/members/music/records/".mysql_result($res,0,'recordid')."/".$id.".mp3";
	print $_GET['callback']."({\"id\":\"".$id."\", \"url\":\"".$url."\", \"title\":\"".$title."\", \"artist\":\"".$artist."\", \"mac\":\"000000000000\"})";
}

//if there are no macs defined getRandom
if($_GET['macs']=='') {
	getRandom();
	exit();
}

//else for each mac, find uid
$macs = explode('-',$_GET['macs']);
$a=0;
foreach($macs as $mac) {
	$res=query("SELECT users.uid, users.mac, plays.timestamp FROM users,plays WHERE mac = '$mac' AND users.uid = plays.uid ORDER BY plays.timestamp DESC;");
	if(mysql_numrows($res)>0) {
		$users[$a]['uid'] = mysql_result($res,0,'uid');
		$users[$a]['mac'] = mysql_result($res,0,'mac');
		$users[$a]['lastplay'] = mysql_result($res,0,'timestamp');
		$a++;
	}
}

//if there are no registered users, playRandom
if(isset($users)==false) {
	getRandom();
	exit();
}

if(isset($_GET['debug']))
	print_r($users);

function array_sort($array, $on, $order=SORT_ASC)
{
    $new_array = array();
    $sortable_array = array();
    if (count($array) > 0) {
        foreach ($array as $k => $v) {
            if (is_array($v)) {
                foreach ($v as $k2 => $v2) {
                    if ($k2 == $on) {
                        $sortable_array[$k] = $v2;
                    }
                }
            } else {
                $sortable_array[$k] = $v;
            }
        }
        switch ($order) {
            case SORT_ASC:
                asort($sortable_array);
            break;
            case SORT_DESC:
                arsort($sortable_array);
            break;
        }
        foreach ($sortable_array as $k => $v) {
            $new_array[$k] = $array[$k];
        }
    }
    return $new_array;
}

$priority = array_sort($users, 'lastplay', SORT_DESC);

if(isset($_GET['debug']))
	print_r($priority);
	

foreach($priority as $user) {
	$uid = $user['uid'];
	$res=query("SELECT artist FROM likes WHERE uid ='$uid' ORDER BY RAND() LIMIT 1;");
	if(mysql_numrows($res)<1) {
		getRandom();
		exit();
	}
	$artists[$uid] = mysql_result($res,0,'artist');
}

if(isset($_GET['debug']))
	print_r($artists);

//due to next itteration, reverse array
//
	
//todo:check plays if recently played

//get a random track by that artist and return jsonp
$a=0;
foreach($artists as $uid => $artist) {
	$playorder[$a]['artist'] = $artist;
	$playorder[$a]['uid'] = $uid;
	$a++;
}

if(isset($_GET['debug']))
	print_r($playorder);

$res=query("SELECT title, artist, trackid, recordid FROM rec_track WHERE digitised AND artist = '{$playorder[0]['artist']}' ORDER BY RAND() LIMIT 1");
$uid = $playorder[0]['uid'];
if(mysql_numrows($res)==0) {
	if(count($playorder)>1) {
	  $res=query("SELECT title, artist, trackid, recordid FROM rec_track WHERE digitised AND artist = '{$playorder[1]['artist']}' ORDER BY RAND() LIMIT 1");
	  $uid = $playorder[1]['uid'];
	}
	else {
	  getRandom();
	  exit();
	}
}
$title = mysql_result($res,0,'title');
$artist = mysql_result($res,0,'artist');
$id = mysql_result($res,0,'trackid');
$url = "http://ury.york.ac.uk/members/music/records/".mysql_result($res,0,'recordid')."/".$id.".mp3";
$mac = mysql_result(query("SELECT mac FROM users WHERE uid ='$uid' LIMIT 1;"),0,'mac');
print $_GET['callback']."({\"id\":\"".$id."\", \"url\":\"".$url."\", \"artist\":\"".$artist."\", \"title\":\"".$title."\",\"mac\":\"".$mac."\"})";
?>