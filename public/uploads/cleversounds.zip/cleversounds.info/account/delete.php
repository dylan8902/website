<?php
include_once('../functions.php');
$user = eatCookie();
query("DELETE FROM users WHERE uid = '$uid';");
query("DELETE FROM plays WHERE uid = '$uid';");
query("DELETE FROM connections WHERE uid = '$uid';");
header("Location: /");
setcookie("session","",2,'/','cleversounds.info');
unset($_COOKIE['session']);
?>