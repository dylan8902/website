<?php
include_once('../functions.php');
$user = eatCookie();
?>
<!DOCTYPE html> 
<html lang='en-gb'> 
<head> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
 	<title>CLEVER SOUNDS</title> 
	<meta name="description" content="Playing your kind of music, wherever you are." /> 
	<meta name="keywords" content="Bluetooth, Music, Jukebox" /> 
  	<meta name="author" content="Dylan Jones" /> 
	<link rel="icon" href="/favicon.ico" type="image/x-icon" /> 
	<?php include('../style.php'); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script>
	$(document).ready(function() {
		$('#settings').toggle(function() {
			$('#setting-choices').fadeIn(500);
		},function() {
			$('#setting-choices').fadeOut(500);
		});
	});
	</script>
</head> 
<body>
	<h1>CLEVER SOUNDS</h1>
	<p class='nav'><a href='/' class='tab'>HOME</a> <a href='/' id='settings' class='tab'>SETTINGS</a> <a href='/account/?logout=1'' class='tab'>LOGOUT</a></p>
	<p id='setting-choices' class='box'><a href='link.php'>LINK ACCOUNTS</a> | <a href='mac.php?reset=<?php print $user['uid']; ?>'>CHANGE PHONE</a> | <a href='password.php'>CHANGE PASSWORD</a> | <a href='delete.php'>DELETE ACCOUNT</a></p>
	<h2>What music do you like? If you have some of these accounts, then they can let us know for you!</h2>
	<p><a href='/facebook/'><img src='http://dylanjones.info/images/icons/facebook_32.png' /></a> <a href='/facebook/'>Facebook</a> <?php if(isset($user['likes']['facebook'])){ print "<img src='/images/tick.png' height='30' />"; } ?></p> 
	<p><a href='/lastfm/'><img src='http://dylanjones.info/images/icons/lastfm_32.png' /></a> <a href='/lastfm/'>LastFM</a> <?php if(isset($user['likes']['lastfm'])){ print "<img src='/images/tick.png' height='30' />"; } ?></p>
</body>
</html>