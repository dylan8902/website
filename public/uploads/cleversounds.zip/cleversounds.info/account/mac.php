<?php
include_once('../functions.php');
$user = eatCookie();

//is mac being registered?
if(isset($_POST['mac'])) {
	//strip crap
	$crap = array (" ","-",":");
	$mac = str_replace($crap,"",$_POST['mac']);
	//is it valid?
	if(strlen($mac)=='12') {
		//store and return to /account/
		query("UPDATE users SET mac = '$mac' WHERE uid = '{$user['uid']}' LIMIT 1");
		header('Location: /account');
		exit();
	}
	else {
		print "Not a valid MAC.";
		exit();
	}
}

//is mac being reset?
if(isset($_GET['reset'])) {
	query("UPDATE users SET mac = '0' WHERE uid = '{$_GET['reset']}' LIMIT 1");
	header('Location: /account');
	exit();
}
?>
<!DOCTYPE html> 
<html lang='en-gb'> 
<head> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
 	<title>CLEVER SOUNDS</title> 
	<meta name="description" content="Playing your kind of music, wherever you are." /> 
	<meta name="keywords" content="Bluetooth, Music, Jukebox" /> 
  	<meta name="author" content="Dylan Jones" />
	<link rel="icon" href="/favicon.ico" type="image/x-icon" /> 
	<?php include('../style.php'); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script>
		$(document).ready(function() {
			$('.tab').click(function() {
				$('.tab').css("background-color","black");
				$('.tab').css("color","white");
				$(this).css("background-color","white");
				$(this).css("color","black");
				var id = $(this).attr('id');
				$('.box').hide();
				$('#howto-'+id).fadeIn(600);			
			});
		});
	</script>
</head> 
<body>
	<h1>CLEVER SOUNDS</h1>
	<h2>REGISTER YOUR BLUETOOTH PHONE</h2>
	<p id='what' class='box' style='display:block;'>Register your bluetooth enabled handset by typing in the MAC address. For help on finding the address, click on your mobile device.</p>
	<h2>
	  <span id='nokia' class='tab'>NOKIA</span>
	  <span id='sony-ericsson' class='tab'>SONY ERICSSON</span>
	  <span id='iPhone' class='tab'>IPHONE</span>
	</h2>
	<p id='howto-nokia' class='box'>Dial <span style='color:red;'>*#2820#</span> in standby mode and the address will be displayed on screen.</p>
	<p id='howto-sony-ericsson' class='box'>Coming Soon ...</p>
	<p id='howto-iPhone' class='box'>Go to: <span style='color:red;'>Settings</span>  &gt; <span style='color:red;'>About</span> and it is listed as 'Bluetooth MAC Address'.</p>
	<form id='register-form' method='post' action='mac.php'>
		<label for='mac'>MAC </label> <input type='text' id='mac' name='mac' />
		<input class='submit' type='submit' value='REGISTER' />
	</form>
</body>
</html>