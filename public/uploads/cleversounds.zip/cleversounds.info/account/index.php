<?php
if(isset($_GET['logout'])) {
	header('Location: /');
	setcookie("session","",2,'/','cleversounds.info');
	unset($_COOKIE['session']);
	exit();
}

include_once('../functions.php');
$user = eatCookie();

if($user==0) {
	header('Location: http://cleversounds.info/');
	exit();
}

if($user['mac'] == '0') {
	//register you phone
	include('mac.php');
	exit();
}

$res = query("SELECT * FROM plays WHERE uid = '{$user['uid']}' ORDER BY timestamp DESC LIMIT 15;");
for($a=0;$a<mysql_numrows($res);$a++) {
	$plays[$a]['playid'] = mysql_result($res,$a,'playid');
	$plays[$a]['song'] = mysql_result($res,$a,'song');
	$plays[$a]['location'] = mysql_result($res,$a,'location');
	$plays[$a]['timestamp'] = mysql_result($res,$a,'timestamp');
}

$res = query("SELECT * FROM likes WHERE uid = '{$user['uid']}' AND image != 'null' ORDER BY RAND() LIMIT 7;");
for($a=0;$a<mysql_numrows($res);$a++) {
	$likes[$a]['image'] = mysql_result($res,$a,'image');
	$likes[$a]['artist'] = mysql_result($res,$a,'artist');
}
?>
<!DOCTYPE html> 
<html lang='en-gb'> 
<head> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
 	<title>CLEVER SOUNDS</title> 
	<meta name="description" content="Playing your kind of music, wherever you are." /> 
	<meta name="keywords" content="Bluetooth, Music, Jukebox" /> 
  	<meta name="author" content="Dylan Jones" /> 
	<link rel="icon" href="/favicon.ico" type="image/x-icon" /> 
	<?php include('../style.php'); ?>
	<style>
		#recom { background:#181818; border:2px solid red; margin:5px; padding:5px; color:white; clear:both; }
		#recom h1 { font-size:200%; background:transparent; color:white; margin:0px; }
		#recom img { height:150px; }
		#recom p { background:transparent; margin:3px; padding:2px; font-size:100%; }
		#recom-list { font-size:170%; }
		#reom-data { font-size:75%; }
	</style>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script>
	function hoverInfo (artist) {
			$.ajax({
			  type		: 'GET',
			  dataType	: 'jsonp',
			  url		: '/api/artistinfo.php',
			  data		: 'artist='+artist,
			  success	:
				function(reply){
					$('#recom-data').html('<p><img src="http://www.bbc.co.uk/music/images/artists/542x305/'+reply.artist.mbid+'.jpg" height=200 /><p>'+reply.artist.bio.summary+'</p><p style="cursor:pointer;color:red;" onclick="javascript:likeArtist(\''+artist+'\');">Sounds Good! Add to my Library</p>');
				}
			});
		}
	$(document).ready(function() {
		$('#settings').toggle(function() {
			$('#setting-choices').fadeIn(500);
		},function() {
			$('#setting-choices').fadeOut(500);
		});
		var refreshId = setInterval(function() {
		  $('#plays').load('/account/home.php?uid=<?php print $user['uid']; ?>');
		}, 50000);
		
		<?php 
		if(isset($likes)) {
		?>
		$.ajax({
			type	: 'GET',
			dataType: 'jsonp',
			url		: '/api/recommendations.php',
			data	: 'artist=<?php print urlencode($likes[0]['artist']); ?>',
			success	: 
			function(reply){
				$('#recom-list').append('<ul>');
				for(var a in reply.response.artists) {
				  $('#recom-list').append("<br><li onclick='javascript:hoverInfo(\""+reply.response.artists[a].name+"\");' style='background:black;padding:2px;color:white;display:inline;cursor:pointer;'>"+reply.response.artists[a].name+"</li><br>");
				}
				$('#recom-list').append('</ul>');
			},
			error	:
			function(){
			}
		});
	
		<?php
		}
		?>

	});
	</script>
</head> 
<body>
	<h1>CLEVER SOUNDS</h1>
	<p class='nav'><a href='/' class='tab'>HOME</a> <a href='/map/' class='tab'>MAP</a> <a href='/' id='settings' class='tab'>SETTINGS</a> <a href='/account/?logout=1' class='tab'>LOGOUT</a> <a href='/jukebox/' class='tab' style='background:#380000;'>DEMO JUKEBOX</a> </p>
	<p id='setting-choices' class='box'><a href='link.php'>LINK ACCOUNTS</a> | <a href='mac.php?reset=<?php print $user['uid']; ?>'>CHANGE PHONE</a> | <a href='password.php'>CHANGE PASSWORD</a> | <a href='delete.php'>DELETE ACCOUNT</a></p>
	
	<?php
	if(isset($user['likes'])) {
		if(isset($plays)) {
			print "<div id='plays' style='float:left;width:85%;'>";
			foreach($plays as $play)
				print "\n<p><span style='color:red;'>{$play['song']}</span> was played at <span style='color:red;'>{$play['location']}</span> ".timeToString($play['timestamp'])."</p>\n";
			print "</div>\n";
		}
		else
			print "<h2>You have not had any songs played for you yet. Check out the map to see locations where CLEVER SOUNDS is available.</h2>\n";
	}
	else {
	?>
		<script>
		var artist;
		function searchArtist() {
			$('.result').hide();
			$('body').append('<p class="result">Loading . . .</p>');
			artist = $('#artist').val();
			$.ajax({
				type	: 'GET',
				dataType: 'jsonp',
				url		: '/api/search.php',
				data	: 'artist='+artist,
				success	: 
				function(reply){
					$('.result').hide();
					artist = reply.response.artists[0].name;
					$('body').append("<p id='artist' class='result' style='cursor:pointer;' onclick='javascript:likeArtist();'>Add <span style='color:red'>"+artist+"</span> to your likes</p>");
				},
				error	:
				function(){
				}
			});
		}
		
		function likeArtist() {
			$.ajax({
			  type     : 'GET',
			  dataType : 'jsonp',
			  url      : '/api/like.php',
			  data     : 'source=website&uid=<?php print $user['uid']; ?>&image=null&artist='+artist,
			  success  : 
				function(reply){
					$('.result').hide();
					$('body').append('<p>Added: '+artist+'</p>');
				}
			});			
		}
		</script>
		<h2>You need to tell us what music you like! You can <a href='link.php'>let these sites tell us:</a></h2>
		<p>
		 <a href='/facebook/'><img src='http://dylanjones.info/images/icons/facebook_32.png' /></a> <a href='/facebook/'>Facebook</a> <?php if(isset($user['likes']['facebook'])){ print "<img src='/images/tick.png' height='30' />"; } ?> <br>
		 <a href='/lastfm/'><img src='http://dylanjones.info/images/icons/lastfm_32.png' /></a> <a href='/lastfm/'>LastFM</a> <?php if(isset($user['likes']['lastfm'])){ print "<img src='/images/tick.png' height='30' />"; } ?>
		</p>
		<h2>OR type in an artist below.</h2>
		<h2><input id='artist' type='text' /> <button onclick='javascript:searchArtist();'>search</button></h2>

	<?php	
	}
	?>
	<div id='likes' style='float:right;width:14%;text-align:center;font-size:85%;'>
	<?php
	if(isset($likes)) {
		print "<p>YOU LIKE</p>";
		foreach($likes as $like)
			print "\n<p><img src='{$like['image']}' style='max-width:100px' /><br>{$like['artist']}</p>";
	}
	?>
	</div>
	<?php
	if(isset($likes)) {
	?>
	<script>
	  function likeArtist(artist) {
			$.ajax({
			  type     : 'GET',
			  dataType : 'jsonp',
			  url      : '/api/like.php',
			  data     : 'source=website&uid=<?php print $user['uid']; ?>&image=null&artist='+artist,
			  success  : 
				function(reply){
					$('.result').hide();
					$('body').append('<p class="hide">Added: '+artist+'</p>');
					setTimeout(function() {
					  $('.hide').hide();
					},2000);
					
				}
			});			
		}
	</script>
	<div id='recom'>
		<h1>Recommendation Box</h1>
		<div id='recom-list' style='float:left; width:40%;'></div>
		<div id='recom-data' style='float:right; width:50%;'></div>
		<div style='clear:both;'></div>
	</div>
	<?php
	}
	?>
</body>
</html>