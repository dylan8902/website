<?php
include_once('../functions.php');
$res = query("SELECT * FROM plays WHERE uid = '{$_GET['uid']}' ORDER BY timestamp DESC LIMIT 500;");
for($a=0;$a<mysql_numrows($res);$a++) {
	$plays[$a]['playid'] = mysql_result($res,$a,'playid');
	$plays[$a]['song'] = mysql_result($res,$a,'song');
	$plays[$a]['location'] = mysql_result($res,$a,'location');
	$plays[$a]['timestamp'] = mysql_result($res,$a,'timestamp');
}
if(count($plays)>0) {
	foreach($plays as $play)
		print "\n<p><span style='color:red;'>{$play['song']}</span> was played at <span style='color:red;'>{$play['location']}</span> ".timeToString($play['timestamp'])."</p>\n";
}
else
	print "<h2>You have not had any songs played for you yet. Check out the map to see locations where CLEVER SOUNDS is available.</h2>\n";
?>