<?php
include_once('../functions.php');
$user = eatCookie();
if((isset($_POST['password']))&&(isset($_POST['oldpassword']))&&(isset($_POST['password-again']))) {
	$uid = $user['uid'];	
	$oldpassword = mysql_result(query("SELECT password FROM users WHERE uid = '$uid';"),0,'password');
	if(md5($_POST['oldpassword'])==$oldpassword) {
		if($_POST['password']==$_POST['password-again']) {
			query("UPDATE users SET password = '".md5($_POST['password'])."' WHERE uid = '$uid' LIMIT 1;");
			header('Location: /');
		}
		else {
			print "Passwords do not match.";
			exit();	
		}
	}
	else {
		print "Wrong password.";
		exit();
	}
}
?>
<!DOCTYPE html> 
<html lang='en-gb'> 
<head> 
	<meta http-equiv="content-type" content="text/html; charset=utf-8" /> 
 	<title>CLEVER SOUNDS</title> 
	<meta name="description" content="Playing your kind of music, wherever you are." /> 
	<meta name="keywords" content="Bluetooth, Music, Jukebox" /> 
  	<meta name="author" content="Dylan Jones" /> 
	<link rel="icon" href="/favicon.ico" type="image/x-icon" /> 
	<?php include('../style.php'); ?>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
	<script>
	$(document).ready(function() {
		$('#settings').toggle(function() {
			$('#setting-choices').fadeIn(500);
		},function() {
			$('#setting-choices').fadeOut(500);
		});
	});
	</script>
</head> 
<body>
	<h1>CLEVER SOUNDS</h1>
	<p class='nav'><a href='/' class='tab'>HOME</a> <a href='/' id='settings' class='tab'>SETTINGS</a> <a href='/account/?logout=1'' class='tab'>LOGOUT</a></p>
	<p id='setting-choices' class='box'><a href='link.php'>LINK ACCOUNTS</a> | <a href='mac.php?reset=<?php print $user['uid']; ?>'>CHANGE PHONE</a> | <a href='password.php'>CHANGE PASSWORD</a> | <a href='delete.php'>DELETE ACCOUNT</a></p>
	<form id='register-form' method='post' action='password.php'>
		<table>
			<tr><td><label for='oldpassword'>Old Password </label> </td><td><input type='password' id='oldpassword' name='oldpassword' /></td></tr>
			<tr><td><label for='password'>New Password</label> </td><td><input type='password' id='password' name='password' /></td></tr>
			<tr><td><label for='password-again'>Confirm Password</label> </td><td><input type='password' id='password-again' name='password-again' /></td></tr>
			<tr><td><input class='submit' type='submit' value='Change Password' /></td></tr>
		</table>
	</form>
</body>
</html>